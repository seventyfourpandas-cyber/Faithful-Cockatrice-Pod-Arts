#!/usr/bin/env python3
"""Install the narrowly scoped WLX Reanimate identity repair."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


EXPECTED_PACKAGE_ID = "willexs-whimsical-arts"
EXPECTED_BASELINE_HASHES = {
    "WLX/source/tools/wlx_bulk_import.py": "b871aab4da05c0db90b0aa131e5e447844ce52515cda21b033d77c132f5b080d",
    "WLX/source/automation/wlxlib.py": "b2627e89a290ba126752ccaa4f12340e979cd000a9cb722ae6fa5e84832700e5",
    "WLX/source/automation/tests/test_bulk_import.py": "3d2000a8433cc80ca39a53d71079ed34d2a0fa37ef807fa559f0558e96981136",
    "WLX/source/cards/Will/catalog.json": "b7624e33d8375ace214d0d28856e65a919414a0999d9a6c216a2e000bb573d4b",
    "WLX/source/automation/data/official_cards_cache.json": "eb90cb06a2291f261966153c2cce102a13b6995add7da2911cc388f006786b87",
    "WLX/source/project.json": "22199c004cf9e03684219a65e6e131b363fe3df779eb56603322e6eb18f945f9",
}

REANIMATE_ENTRY = {
    "name": "Reanimate",
    "oracle_id": "a044474a-cd72-4e9d-bd8d-a08f2de9cdc0",
    "scryfall_uri": "https://scryfall.com/card/dsc/155/reanimate?utm_source=api",
    "layout": "normal",
    "faces": [],
    "verified_at": "2026-08-18",
}

EXPECTED_REANIMATE_PRINTINGS = {
    "405": {
        "uuid": "0a58a2ad-a6d5-5d73-9ad4-30a01e18fecb",
        "image_file": "WLX-405.jpg",
        "image_sha256": "64062438aa96cd7223c93c28d534dfa5efa909b53e744ecdad5005c809f95eb1",
        "notes": "Imported from will/Reanimate __ 1.jpg in file batch 00e246675e",
    },
    "406": {
        "uuid": "8703cd3d-4cac-5862-9cb5-5285508d5a4f",
        "image_file": "WLX-406.jpg",
        "image_sha256": "c71c70a3a2237f9c79a813234dc7cdd915a0ac7f353b9fd2d37f9d12cbca1328",
        "notes": "Imported from will/Reanimate.jpg in file batch 00e246675e",
    },
}

IMPORTER_OLD = '''    aliases = {requested.casefold(), str(details.get("name", "")).casefold()}
    faces = details.get("faces")
    if isinstance(faces, list):
        aliases.update(
            str(face.get("official_name", "")).casefold()
            for face in faces
            if isinstance(face, dict)
        )
    for alias in aliases:
'''

IMPORTER_NEW = '''    aliases = {requested.casefold(), str(details.get("name", "")).casefold()}
    for alias in aliases:
'''

WLXLIB_OLD = '''    """Resolve one official two-faced physical card and cache both face names."""
'''

WLXLIB_NEW = '''    """Resolve one official two-faced physical card without caching face aliases."""
'''

WLXLIB_ALIASES_OLD = '''    aliases = {canonical.casefold(), requested.casefold(), *(name.casefold() for name in face_names)}
'''

WLXLIB_ALIASES_NEW = '''    aliases = {canonical.casefold(), requested.casefold()}
'''

TEST_ANCHOR_OLD = '''    def tearDown(self) -> None:
        self.fixture.close()

    def test_one_batch_imports_one_hundred_images_and_bumps_once(self) -> None:
'''

TEST_ANCHOR_NEW = '''    def tearDown(self) -> None:
        self.fixture.close()

    def test_multiface_lookup_does_not_claim_a_standalone_card_name(self) -> None:
        prepared = {
            "name": "Grave Researcher // Reanimate",
            "oracle_id": "6cb8b8c4-0674-4f14-9d89-010969fbb80e",
            "scryfall_uri": "https://example.invalid/grave-researcher-reanimate",
            "layout": "prepare",
            "faces": [
                {"official_name": "Grave Researcher", "side": "front"},
                {"official_name": "Reanimate", "side": "back"},
            ],
        }
        cache: dict[str, object] = {"schema_version": 1, "cards": {}}
        bulk.cache_card_details(cache, "Grave Researcher", prepared)
        cards = cache["cards"]
        self.assertIsInstance(cards, dict)
        assert isinstance(cards, dict)
        self.assertIn("grave researcher", cards)
        self.assertIn("grave researcher // reanimate", cards)
        self.assertNotIn("reanimate", cards)

    def test_one_batch_imports_one_hundred_images_and_bumps_once(self) -> None:
'''


class InstallError(RuntimeError):
    """A precondition or validation failed."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise InstallError(f"Could not read valid JSON from {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise InstallError(f"Expected a JSON object in {path}")
    return value


def write_text(path: Path, payload: str) -> None:
    temporary = path.with_suffix(path.suffix + ".reanimate-repair.tmp")
    temporary.write_text(payload, encoding="utf-8", newline="\n")
    temporary.replace(path)


def write_json(path: Path, value: dict[str, Any]) -> None:
    write_text(
        path,
        json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + "\n",
    )


def replace_once(path: Path, old: str, new: str) -> bool:
    text = path.read_text(encoding="utf-8")
    occurrences = text.count(old)
    if occurrences == 1:
        write_text(path, text.replace(old, new, 1))
        return True
    if occurrences == 0 and new in text:
        return False
    raise InstallError(
        f"Refusing to patch unexpected contents in {path}; expected one exact source block"
    )


def catalog_printings(catalog: dict[str, Any]) -> dict[str, dict[str, Any]]:
    printings = catalog.get("printings")
    if not isinstance(printings, list):
        raise InstallError("Will/catalog.json has no valid printings list")
    result: dict[str, dict[str, Any]] = {}
    for value in printings:
        if not isinstance(value, dict):
            raise InstallError("Will/catalog.json contains a malformed printing")
        collector = str(value.get("collector_number", ""))
        if collector in result:
            raise InstallError(f"Duplicate collector number {collector!r} in Will/catalog.json")
        result[collector] = value
    return result


def verify_target_printing(
    printing: dict[str, Any], collector: str, allowed_names: set[str]
) -> None:
    expected = EXPECTED_REANIMATE_PRINTINGS[collector]
    for field, wanted in expected.items():
        if printing.get(field) != wanted:
            raise InstallError(
                f"WLX-{collector} has unexpected {field}; no repository data was changed"
            )
    if printing.get("card_kind") != "official":
        raise InstallError(f"WLX-{collector} is no longer an ordinary official printing")
    if printing.get("official_name") not in allowed_names:
        raise InstallError(f"WLX-{collector} has an unexpected card identity")


def is_fully_applied(root: Path) -> bool:
    importer = (root / "WLX/source/tools/wlx_bulk_import.py").read_text(encoding="utf-8")
    library = (root / "WLX/source/automation/wlxlib.py").read_text(encoding="utf-8")
    tests = (root / "WLX/source/automation/tests/test_bulk_import.py").read_text(
        encoding="utf-8"
    )
    catalog = read_json(root / "WLX/source/cards/Will/catalog.json")
    printings = catalog_printings(catalog)
    cache = read_json(root / "WLX/source/automation/data/official_cards_cache.json")
    cards = cache.get("cards")
    if not isinstance(cards, dict):
        raise InstallError("The official card cache is malformed")
    targets_are_fixed = all(
        collector in printings and printings[collector].get("official_name") == "Reanimate"
        for collector in EXPECTED_REANIMATE_PRINTINGS
    )
    return (
        IMPORTER_NEW in importer
        and IMPORTER_OLD not in importer
        and WLXLIB_NEW in library
        and WLXLIB_ALIASES_NEW in library
        and WLXLIB_ALIASES_OLD not in library
        and "test_multiface_lookup_does_not_claim_a_standalone_card_name" in tests
        and targets_are_fixed
        and cards.get("reanimate") == REANIMATE_ENTRY
    )


def verify_baseline(root: Path) -> None:
    mismatches = []
    for relative, expected in EXPECTED_BASELINE_HASHES.items():
        path = root / relative
        if not path.is_file():
            mismatches.append(f"{relative} is missing")
            continue
        actual = sha256(path)
        if actual != expected:
            mismatches.append(f"{relative} differs from the supported repository revision")
    if mismatches:
        raise InstallError("\n".join(mismatches))


def verify_card_manager_is_clean(root: Path) -> None:
    command = [
        sys.executable,
        str(root / "WLX/source/tools/wlx_catalog_manager.py"),
        "--repository-root",
        str(root),
        "--status",
    ]
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    if result.returncode != 0 or result.stdout.strip() != "clean":
        detail = (result.stderr or result.stdout).strip()
        raise InstallError(
            "CARD_MANAGER.csv has pending or invalid edits. Apply those in a separate "
            f"commit before this repair. {detail}"
        )


def snapshot_double_faced_printings(root: Path) -> dict[tuple[str, str], dict[str, Any]]:
    snapshot: dict[tuple[str, str], dict[str, Any]] = {}
    for path in sorted((root / "WLX/source/cards").glob("*/catalog.json")):
        catalog = read_json(path)
        for collector, printing in catalog_printings(catalog).items():
            if printing.get("card_kind") == "official_double_faced":
                snapshot[(path.parent.name, collector)] = deepcopy(printing)
    return snapshot


def repair_catalog(root: Path) -> None:
    path = root / "WLX/source/cards/Will/catalog.json"
    before = read_json(path)
    before_printings = catalog_printings(before)
    if "305" not in before_printings:
        raise InstallError("The existing Grave Researcher printing WLX-305 is missing")
    protected_305 = deepcopy(before_printings["305"])
    for collector in EXPECTED_REANIMATE_PRINTINGS:
        if collector not in before_printings:
            raise InstallError(f"The expected Reanimate art WLX-{collector} is missing")
        verify_target_printing(
            before_printings[collector],
            collector,
            {"Grave Researcher // Reanimate"},
        )

    text = path.read_text(encoding="utf-8")
    for collector, expected in EXPECTED_REANIMATE_PRINTINGS.items():
        old = (
            f'      "collector_number": "{collector}",\n'
            f'      "uuid": "{expected["uuid"]}",\n'
            '      "card_kind": "official",\n'
            '      "official_name": "Grave Researcher // Reanimate",'
        )
        new = old.replace(
            '"official_name": "Grave Researcher // Reanimate"',
            '"official_name": "Reanimate"',
        )
        if text.count(old) != 1:
            raise InstallError(f"Could not identify the exact WLX-{collector} catalog block")
        text = text.replace(old, new, 1)
    write_text(path, text)

    after = read_json(path)
    after_printings = catalog_printings(after)
    if after_printings.get("305") != protected_305:
        raise InstallError("The repair unexpectedly changed WLX-305")
    for collector in EXPECTED_REANIMATE_PRINTINGS:
        verify_target_printing(after_printings[collector], collector, {"Reanimate"})
    for collector, printing in before_printings.items():
        if collector not in EXPECTED_REANIMATE_PRINTINGS and after_printings.get(collector) != printing:
            raise InstallError(f"The repair unexpectedly changed WLX-{collector}")


def repair_cache(root: Path) -> None:
    path = root / "WLX/source/automation/data/official_cards_cache.json"
    cache = read_json(path)
    cards = cache.get("cards")
    if not isinstance(cards, dict):
        raise InstallError("The official card cache is malformed")
    stale = cards.get("reanimate")
    if not isinstance(stale, dict) or stale.get("name") != "Grave Researcher // Reanimate":
        raise InstallError("The stale Reanimate cache entry was not found as expected")
    cards["reanimate"] = deepcopy(REANIMATE_ENTRY)
    write_json(path, cache)


def bump_project(root: Path) -> None:
    path = root / "WLX/source/project.json"
    project = read_json(path)
    if project.get("package_id") != EXPECTED_PACKAGE_ID:
        raise InstallError("This ZIP is for the Willex's Whimsical Arts repository only")
    if project.get("version") != "3.2.12":
        raise InstallError(
            f"Expected project version 3.2.12, found {project.get('version')!r}"
        )
    project["version"] = "3.2.13"
    project["release_created_at"] = datetime.now(timezone.utc).isoformat(
        timespec="seconds"
    )
    write_json(path, project)


def validate_repository(root: Path) -> None:
    command = [
        sys.executable,
        str(root / "WLX/source/automation/build.py"),
        "--repository-root",
        str(root),
        "--validate-only",
    ]
    result = subprocess.run(command, cwd=root, text=True)
    if result.returncode != 0:
        raise InstallError("Repository validation failed after the Reanimate repair")


def install(root: Path, package_root: Path) -> None:
    if not (package_root / "install.py").is_file():
        raise InstallError("The extracted repair package is incomplete")
    project_path = root / "WLX/source/project.json"
    if not project_path.is_file():
        raise InstallError("Run this installer from the Faithful Cockatrice repository")
    project = read_json(project_path)
    if project.get("package_id") != EXPECTED_PACKAGE_ID:
        raise InstallError("This ZIP is for the Willex's Whimsical Arts repository only")

    if is_fully_applied(root):
        validate_repository(root)
        print("The Reanimate-only repair is already installed; nothing changed.")
        return

    verify_card_manager_is_clean(root)
    verify_baseline(root)
    double_faced_before = snapshot_double_faced_printings(root)

    replace_once(root / "WLX/source/tools/wlx_bulk_import.py", IMPORTER_OLD, IMPORTER_NEW)
    replace_once(root / "WLX/source/automation/wlxlib.py", WLXLIB_OLD, WLXLIB_NEW)
    replace_once(
        root / "WLX/source/automation/wlxlib.py",
        WLXLIB_ALIASES_OLD,
        WLXLIB_ALIASES_NEW,
    )
    replace_once(
        root / "WLX/source/automation/tests/test_bulk_import.py",
        TEST_ANCHOR_OLD,
        TEST_ANCHOR_NEW,
    )
    repair_catalog(root)
    repair_cache(root)
    bump_project(root)

    double_faced_after = snapshot_double_faced_printings(root)
    if double_faced_after != double_faced_before:
        raise InstallError("The repair unexpectedly altered a double-faced printing")
    validate_repository(root)
    print(
        "Installed Reanimate-only repair: WLX-405 and WLX-406 now resolve to "
        "standalone Reanimate; double-faced printings and token behavior were untouched."
    )


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--repository-root", type=Path, required=True)
    result.add_argument("--package-root", type=Path, required=True)
    return result


def main() -> int:
    arguments = parser().parse_args()
    try:
        install(arguments.repository_root.resolve(), arguments.package_root.resolve())
        return 0
    except (InstallError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
