#!/usr/bin/env python3
"""Install the WLX v3.0.1 saved-manifest migration fix."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import shutil
from pathlib import Path


EXPECTED_PAYLOAD = {
    "WLX/source/automation/installer_source/WLX_Bootstrap.ps1",
    "WLX/source/automation/tests/powershell_integration.py",
}
PACKAGE_ID = "willexs-whimsical-arts"
FIX_VERSION = (3, 0, 1)


def parse_semver(value: str) -> tuple[int, int, int]:
    pieces = value.split(".")
    if len(pieces) != 3 or not all(piece.isdigit() for piece in pieces):
        raise RuntimeError(f"Unsupported current WLX version: {value!r}")
    return tuple(int(piece) for piece in pieces)  # type: ignore[return-value]


def load_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"Expected a JSON object in {path}")
    return value


def write_json(path: Path, value: dict[str, object]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    temporary.replace(path)


def install(repository_root: Path, package_root: Path) -> None:
    repository_root = repository_root.resolve()
    package_root = package_root.resolve()

    required = (
        repository_root / ".github" / "workflows" / "import-wlx-cards.yml",
        repository_root / "imports" / "incoming",
        repository_root / "WLX" / "source" / "project.json",
        repository_root / "WLX" / "published",
    )
    missing = [
        str(path.relative_to(repository_root)) for path in required if not path.exists()
    ]
    if missing:
        raise RuntimeError(
            "The repository is not in the expected organized layout; missing: "
            + ", ".join(missing)
        )

    payload_root = package_root / "payload"
    actual_payload = {
        path.relative_to(payload_root).as_posix()
        for path in payload_root.rglob("*")
        if path.is_file()
    }
    if actual_payload != EXPECTED_PAYLOAD:
        raise RuntimeError(
            "The 404-fix payload file list is wrong; missing="
            f"{sorted(EXPECTED_PAYLOAD - actual_payload)}, "
            f"unexpected={sorted(actual_payload - EXPECTED_PAYLOAD)}"
        )

    project_path = repository_root / "WLX" / "source" / "project.json"
    project = load_json(project_path)
    if project.get("package_id") != PACKAGE_ID:
        raise RuntimeError("This patch belongs to a different WLX repository.")

    for relative in sorted(EXPECTED_PAYLOAD):
        source = payload_root / relative
        destination = repository_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        shutil.copy2(source, temporary)
        temporary.replace(destination)

    current_version = parse_semver(str(project.get("version", "")))
    if current_version < FIX_VERSION:
        project["version"] = ".".join(str(piece) for piece in FIX_VERSION)
        project["release_created_at"] = dt.datetime.now(dt.timezone.utc).isoformat(
            timespec="seconds"
        )
        write_json(project_path, project)

    marker = repository_root / "WLX" / "source" / ".wlx-bulk-importer-installed"
    marker.write_text("3.0.1\n", encoding="utf-8", newline="\n")
    print(
        "Installed WLX v3.0.1: old saved manifest URLs will now be migrated "
        "without changing any cards or artwork."
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository-root", type=Path, required=True)
    parser.add_argument("--package-root", type=Path, required=True)
    arguments = parser.parse_args()
    install(arguments.repository_root, arguments.package_root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
