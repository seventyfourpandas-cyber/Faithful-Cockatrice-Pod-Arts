#!/usr/bin/env python3
"""Install WLX Card Manager artwork replacement support v3.2.0."""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path


PACKAGE_ID = "willexs-whimsical-arts"
FEATURE_VERSION = "3.2.0"
SEMVER_RE = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg"}

PAYLOAD_HASHES = {
    "README.md": "385da9f128ef52319f2113d9247f2d1fae771f0496f4122acf3ff68c86761fb5",
    "WLX/docs/BULK_IMPORT_GUIDE.md": "169450dbe12cecf1655fb481ea5a5540fadf122fad0c75b49be44b5d29d1a973",
    "WLX/docs/CARD_MANAGER_GUIDE.md": "d227541696173386432af5faa0a418c70dccf57f79aa6cec1d648e53fff6f82c",
    "WLX/docs/OWNER_GUIDE.md": "1549d41225df9e4db6b483fd791db2737d5467b5792e0444e339407d697e018c",
    "WLX/source/.wlx-bulk-importer-installed": "33bdaf9e2d6bcbde2e4e613e865e403f8fe21fc621078d34c30b0bdc7f68d903",
    "WLX/source/automation/tests/test_catalog_manager.py": "88cd5f40bb69bbd569a16b5a878a285b201bc80ec1e85a0d6824b9141dc5c705",
    "WLX/source/automation/wlxlib.py": "b2627e89a290ba126752ccaa4f12340e979cd000a9cb722ae6fa5e84832700e5",
    "WLX/source/bulk_import_config.json": "d2cab6c766ccf4a2d99e8547ff0dc9f7e4b1884995ccfd5c771d622c575b1379",
    "WLX/source/tools/wlx_catalog_manager.py": "32e941ae89f1183d9854032bba9360f82954b34a8b1a8b1a637601f8f68284ff",
    "imports/replacements/alex/PUT_REPLACEMENT_ART_HERE.txt": "d2aa4e24af4e0d90250fb9c438cdcbf41d3f1ffd3e886b51f539f6f21565fc8c",
    "imports/replacements/jay/PUT_REPLACEMENT_ART_HERE.txt": "2d5f42bce97b761fea2f13a189acf94b10703cc9070197b7b69a0223aec8df2f",
    "imports/replacements/miguel/PUT_REPLACEMENT_ART_HERE.txt": "eaa3eb14495b6903fcf338f6de3009bf34c125c6c5327255c08491ec9f53c564",
    "imports/replacements/will/PUT_REPLACEMENT_ART_HERE.txt": "daab4784cee72a3300cf2008d69f3c1bcc4dd95d8aa98e841a303b7bb1d81e43",
}

OLD_HASHES = {
    "README.md": "deba348ed1bd15ab4eb452de695104b8870dcbb978517a05740e78568bc7118d",
    "WLX/docs/BULK_IMPORT_GUIDE.md": "b56fef21ac6dd3958da6cefe3c8bbd8cae58b8cba43097828086efc6e9274144",
    "WLX/docs/CARD_MANAGER_GUIDE.md": "727111fb3fd0f11f381683c547d7913caa7a026d1dae2d2bb2878771df43f9a6",
    "WLX/docs/OWNER_GUIDE.md": "5c78230f3220cb5a99e7da3251509c10fd896b2e39fec955fdf0ff20564bda5e",
    "WLX/source/.wlx-bulk-importer-installed": "6dc3b2dc3139b7d421b6fc26a7f853389a9b035ea4f2e9047b9516050dd6ac73",
    "WLX/source/automation/tests/test_catalog_manager.py": "5cd94153436066c80743a321edd9f9d384e5d5241b1cb325f4f4fa74f0d5301f",
    "WLX/source/automation/wlxlib.py": "7463308037a0ea294f927f36f3c4bdfe0db36f3116916bffb47b9cbfa663edee",
    "WLX/source/bulk_import_config.json": "ee5939a3121cb9baa8771958630020eca006d632c8475ddbc1b0955eaa0da21e",
    "WLX/source/tools/wlx_catalog_manager.py": "776a20f48cc4e52fb4b7a84347edb447fa0bab8f153cfbb6436a9c8656650099",
}


class InstallError(RuntimeError):
    """A safe feature-install rejection."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    temporary.replace(path)


def semver(value: str) -> tuple[int, int, int]:
    match = SEMVER_RE.fullmatch(value)
    if match is None:
        raise InstallError(f"project.json has an invalid version: {value!r}")
    return tuple(int(part) for part in value.split("."))


def validate_manager_has_no_pending_request(root: Path) -> None:
    path = root / "WLX" / "CARD_MANAGER.csv"
    try:
        handle = path.open("r", encoding="utf-8-sig", newline="")
    except FileNotFoundError as exc:
        raise InstallError("WLX/CARD_MANAGER.csv is missing") from exc
    with handle:
        reader = csv.DictReader(handle)
        change_fields = [
            field for field in (reader.fieldnames or []) if field.startswith("CHANGE_")
        ]
        if not change_fields:
            raise InstallError("CARD_MANAGER.csv has no recognized CHANGE_ columns")
        if any(
            str(row.get(field) or "").strip()
            for row in reader
            for field in change_fields
        ):
            raise InstallError(
                "CARD_MANAGER.csv already contains a pending request. Let it finish or clear it before installing v3.2.0."
            )


def validate_incoming_queue_is_empty(root: Path) -> None:
    incoming = root / "imports" / "incoming"
    queued = sorted(
        path.relative_to(root).as_posix()
        for path in incoming.rglob("*")
        if path.is_file() and path.suffix.casefold() in IMAGE_SUFFIXES
    ) if incoming.is_dir() else []
    if queued:
        raise InstallError(
            "The ordinary import queue still contains card images. Let the current import finish before installing v3.2.0: "
            + ", ".join(queued[:5])
        )


def validate_payload(payload_root: Path) -> None:
    expected = set(PAYLOAD_HASHES)
    actual: set[str] = set()
    for path in payload_root.rglob("*"):
        if path.is_symlink():
            raise InstallError(f"The installer payload contains a symbolic link: {path.name}")
        if path.is_file():
            actual.add(path.relative_to(payload_root).as_posix())
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise InstallError(
            f"The installer payload is incomplete or unexpected; missing={missing}, extra={extra}"
        )
    if any(Path(relative).parts[0] == ".github" for relative in actual):
        raise InstallError("This feature installer is not allowed to change .github")
    for relative, wanted_hash in PAYLOAD_HASHES.items():
        source = payload_root / relative
        if sha256_file(source) != wanted_hash:
            raise InstallError(f"The installer integrity check failed for {relative}")


def validate_targets(root: Path) -> bool:
    already_installed = True
    for relative, new_hash in PAYLOAD_HASHES.items():
        target = root / relative
        old_hash = OLD_HASHES.get(relative)
        if target.exists() and not target.is_file():
            raise InstallError(f"The install target is not a normal file: {relative}")
        if target.is_symlink():
            raise InstallError(f"The install target is a symbolic link: {relative}")
        if not target.exists():
            if old_hash is not None:
                raise InstallError(f"The repository is missing the expected file: {relative}")
            already_installed = False
            continue
        current_hash = sha256_file(target)
        if current_hash == new_hash:
            continue
        already_installed = False
        if old_hash is None or current_hash != old_hash:
            raise InstallError(
                f"{relative} changed after this installer was tested. Nothing was overwritten."
            )
    return already_installed


def install(root: Path, package_root: Path) -> None:
    payload_root = package_root / "payload"
    project_path = root / "WLX" / "source" / "project.json"
    try:
        project = json.loads(project_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        raise InstallError("The repository has no valid WLX/source/project.json") from exc
    if not isinstance(project, dict) or project.get("package_id") != PACKAGE_ID:
        raise InstallError("This is not the Willex's Whimsical Arts repository")

    validate_payload(payload_root)
    validate_manager_has_no_pending_request(root)
    validate_incoming_queue_is_empty(root)
    already_installed = validate_targets(root)

    backup_root = Path(tempfile.mkdtemp(prefix="wlx-card-manager-v320-"))
    existed: dict[str, bool] = {}
    all_targets = list(PAYLOAD_HASHES) + ["WLX/source/project.json"]
    try:
        for relative in all_targets:
            target = root / relative
            existed[relative] = target.is_file()
            if target.is_file():
                backup = backup_root / relative
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup)

        try:
            for relative in PAYLOAD_HASHES:
                source = payload_root / relative
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                pending = target.with_suffix(target.suffix + ".v320.tmp")
                shutil.copy2(source, pending)
                pending.replace(target)

            current_version = str(project.get("version", ""))
            if semver(current_version) < semver(FEATURE_VERSION):
                project["version"] = FEATURE_VERSION
            if not already_installed:
                project["release_created_at"] = dt.datetime.now(
                    dt.timezone.utc
                ).isoformat(timespec="seconds")
            write_json(project_path, project)

            for relative, wanted_hash in PAYLOAD_HASHES.items():
                if sha256_file(root / relative) != wanted_hash:
                    raise InstallError(f"Post-install verification failed for {relative}")
        except Exception:
            for relative in all_targets:
                target = root / relative
                backup = backup_root / relative
                if existed[relative]:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(backup, target)
                elif target.exists():
                    target.unlink()
            raise
    finally:
        shutil.rmtree(backup_root, ignore_errors=True)

    if already_installed:
        print("WLX Card Manager artwork replacement v3.2.0 was already installed.")
    else:
        print("Installed WLX Card Manager artwork replacement v3.2.0.")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--repository-root", required=True, type=Path)
    result.add_argument("--package-root", required=True, type=Path)
    return result


def main() -> int:
    arguments = parser().parse_args()
    try:
        install(arguments.repository_root.resolve(), arguments.package_root.resolve())
        return 0
    except (InstallError, OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
