#!/usr/bin/env python3
"""Repair the WLX installer integration test and resume the waiting import."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


PACKAGE_ID = "willexs-whimsical-arts"
TARGET_RELATIVE = Path(
    "WLX/source/automation/tests/powershell_integration.py"
)
ORIGINAL_TARGET_HASH = (
    "d9654d8758916631fe5ab14175159d92871761528ffdfdca80c3bbb7679528b7"
)
REPAIRED_TARGET_HASH = (
    "0f9dc767f254df2f6748bc1619c719f9afaa0224b207a27991c4a21efeccba77"
)
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg"}


class InstallError(RuntimeError):
    """A safe repair-package rejection."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_repository(root: Path) -> None:
    project_path = root / "WLX" / "source" / "project.json"
    try:
        project = json.loads(project_path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        raise InstallError("The repository has no valid WLX/source/project.json") from exc
    if not isinstance(project, dict) or project.get("package_id") != PACKAGE_ID:
        raise InstallError("This is not the Willex's Whimsical Arts repository")


def validate_payload(package_root: Path) -> Path:
    payload_root = package_root / "payload"
    wanted = TARGET_RELATIVE.as_posix()
    actual: set[str] = set()
    for path in payload_root.rglob("*"):
        if path.is_symlink():
            raise InstallError("The repair payload contains a symbolic link")
        if path.is_file():
            actual.add(path.relative_to(payload_root).as_posix())
    if actual != {wanted}:
        raise InstallError(
            f"The repair payload is incomplete or unexpected: {sorted(actual)}"
        )
    payload = payload_root / TARGET_RELATIVE
    if sha256_file(payload) != REPAIRED_TARGET_HASH:
        raise InstallError("The repair payload failed its integrity check")
    return payload


def require_clean_card_manager(root: Path) -> None:
    manager = root / "WLX" / "source" / "tools" / "wlx_catalog_manager.py"
    result = subprocess.run(
        [
            sys.executable,
            str(manager),
            "--repository-root",
            str(root),
            "--status",
        ],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    status = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else ""
    if result.returncode != 0 or status != "clean":
        raise InstallError(
            "CARD_MANAGER.csv has a pending or invalid request; nothing was changed. "
            + result.stdout.strip()
        )


def install_test_repair(root: Path, payload: Path) -> bool:
    target = root / TARGET_RELATIVE
    if target.is_symlink() or not target.is_file():
        raise InstallError(f"The expected test file is missing: {TARGET_RELATIVE}")
    current_hash = sha256_file(target)
    if current_hash == REPAIRED_TARGET_HASH:
        return False
    if current_hash != ORIGINAL_TARGET_HASH:
        raise InstallError(
            "The installer integration test changed after this repair was verified. "
            "Nothing was overwritten."
        )
    temporary = target.with_suffix(target.suffix + ".repair.tmp")
    try:
        shutil.copy2(payload, temporary)
        if sha256_file(temporary) != REPAIRED_TARGET_HASH:
            raise InstallError("The copied repair failed verification")
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    return True


def queued_images(root: Path) -> list[Path]:
    incoming = root / "imports" / "incoming"
    if not incoming.is_dir():
        return []
    return sorted(
        (
            path
            for path in incoming.rglob("*")
            if path.is_file() and path.suffix.casefold() in IMAGE_SUFFIXES
        ),
        key=lambda path: path.as_posix().casefold(),
    )


def resume_queue(
    root: Path,
    *,
    batch_id: str,
    fixture_dir: Path | None,
) -> None:
    images = queued_images(root)
    if not images:
        print("No WLX card images are waiting; installed only the test repair.")
        return
    importer = root / "WLX" / "source" / "tools" / "wlx_bulk_import.py"
    command = [
        sys.executable,
        str(importer),
        "--repository-root",
        str(root),
    ]
    if batch_id:
        command.extend(["--batch-id", batch_id[:10]])
    if fixture_dir is not None:
        command.extend(["--fixture-dir", str(fixture_dir.resolve())])
    print(f"Resuming the waiting WLX batch ({len(images)} images).", flush=True)
    result = subprocess.run(command, cwd=root, check=False)
    if result.returncode != 0:
        raise InstallError(
            f"The waiting batch could not be resumed (exit code {result.returncode})"
        )
    report = root / "imports" / "LAST_RUN.md"
    if report.is_file():
        print(report.read_text(encoding="utf-8"), end="")


def install(
    root: Path,
    package_root: Path,
    *,
    batch_id: str,
    fixture_dir: Path | None,
) -> None:
    validate_repository(root)
    payload = validate_payload(package_root)
    require_clean_card_manager(root)
    changed = install_test_repair(root, payload)
    resume_queue(root, batch_id=batch_id, fixture_dir=fixture_dir)
    if changed:
        print("Installed the WLX large-batch integration-test repair.")
    else:
        print("The WLX large-batch integration-test repair was already installed.")


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--repository-root", required=True, type=Path)
    result.add_argument("--package-root", required=True, type=Path)
    result.add_argument("--batch-id", default="")
    result.add_argument("--fixture-dir", type=Path, default=None)
    return result


def main() -> int:
    arguments = parser().parse_args()
    batch_id = (
        arguments.batch_id.strip()
        or os.environ.get("BATCH_ID", "").strip()
        or os.environ.get("GITHUB_SHA", "").strip()
    )
    try:
        install(
            arguments.repository_root.resolve(),
            arguments.package_root.resolve(),
            batch_id=batch_id,
            fixture_dir=arguments.fixture_dir,
        )
        return 0
    except (InstallError, OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
