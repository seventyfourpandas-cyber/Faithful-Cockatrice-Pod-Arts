WLX REANIMATE-ONLY REPAIR
===========================

Upload the ZIP file named WLX_LAYOUT_REWIRE_INSTALL.zip to the ROOT of the
Faithful-Cockatrice-Pod-Arts repository and commit it by itself.

The existing "Import WLX card art" GitHub Action will automatically:

1. Extract and run this repair.
2. Remove the uploaded ZIP.
3. Rebuild and test the Cockatrice release.
4. Commit the verified result back to main.

What this repair changes
------------------------

* WLX-405 (art uploaded as Reanimate __ 1.jpg) is corrected in place from
  "Grave Researcher // Reanimate" to the standalone card "Reanimate".
* WLX-406 (art uploaded as Reanimate.jpg) receives the same correction.
* Their collector numbers, UUIDs, image files, image hashes, and notes stay the
  same, so the two existing arts become two printings of Reanimate.
* The importer no longer caches every face name of a multi-face card as if that
  name uniquely identified the whole card. This prevents the same collision
  from being created again.
* A regression test covers the exact Grave Researcher/Reanimate collision.

What this repair does NOT change
--------------------------------

* WLX-305 remains "Grave Researcher // Reanimate".
* Existing double-faced printing records are preserved, and the importer still
  pairs future front/back image uploads by their shared Oracle identity.
* Token importing, token naming, and token relationships are not changed.
* No image file is replaced or recompressed.

After the GitHub Action is green, update the WLX package in Cockatrice using
the normal WLX updater. Reanimate should then offer both WLX-405 and WLX-406 as
its two art printings.
