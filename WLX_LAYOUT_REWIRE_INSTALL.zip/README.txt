WLX CURRENT ACTION REPAIR
=========================

Upload the ZIP containing this file directly to the repository root as:

    WLX_LAYOUT_REWIRE_INSTALL.zip

Do not extract the ZIP and do not upload these inner files separately.

The Import WLX card art Action will:

1. Repair the PowerShell integration test so it finds WLX #001 by collector
   number instead of assuming it is the first alphabetically sorted card.
2. Resume the 100-image batch that is already waiting in imports/incoming.
3. Rebuild and verify the complete public release.
4. Commit the verified repair and import together.

The queued artwork is not stored inside this ZIP. The Action reads the images
that are already committed in imports/incoming, so do not upload them again.

Verified against failed Action run 31733270441 at commit
bf1a6022b4c9c8ff08c2a33cf9615417b795b755.
