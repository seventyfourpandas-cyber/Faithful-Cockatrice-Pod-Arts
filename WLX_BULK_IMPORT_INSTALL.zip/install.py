#!/usr/bin/env python3
"""Install the clean WLX file importer into an existing WLX repository."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path


PACKAGE_ID = "willexs-whimsical-arts"
MARKER = ".wlx-bulk-importer-installed"

LEGACY_FILES = (
    "DROP_CARD_IMAGES_HERE.txt",
    "PUT_ALEX_CARD_IMAGES_HERE.txt",
    "PUT_JAY_CARD_IMAGES_HERE.txt",
    "PUT_MIGUEL_CARD_IMAGES_HERE.txt",
    "PUT_WILL_CARD_IMAGES_HERE.txt",
    "README_IMPORTER.txt",
    "READ_ME_FIRST.md",
    "RUN_IMPORTER_LOCALLY.bat",
    "WHAT_TO_UPLOAD.txt",
    "importer_config.json",
    "requirements-importer.txt",
    "tools/wlx_importer.py",
    "download",
    "download (1)",
    "download (2)",
    "download (3)",
    "download (4)",
    "Willexs_Whimsical_Arts_Installer_v1.0.4.zip",
)

LEGACY_DIRECTORIES = (
    ".wlx-result",
    "UPLOAD_TO_GITHUB",
    "automation/__pycache__",
    "automation/tests/__pycache__",
)

LEGACY_ISSUE_FORMS = (
    "01-add-printing.yml",
    "02-add-double-faced-printing.yml",
    "02b-add-token-printing.yml",
    "03-add-original-card.yml",
    "04-add-printing-advanced.yml",
    "05-update-printing.yml",
    "06-update-double-faced-printing.yml",
    "07-update-original-card.yml",
    "08-remove-printing.yml",
    "add-printing.yml",
    "add-double-faced-printing.yml",
    "add-token-printing.yml",
    "add-original-card.yml",
    "add-printing-advanced.yml",
    "update-printing.yml",
    "update-double-faced-printing.yml",
    "update-original-card.yml",
    "remove-printing.yml",
)


def remove_path(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)


def copy_payload(payload_root: Path, repository_root: Path) -> int:
    copied = 0
    for source in sorted(payload_root.rglob("*"), key=lambda item: item.as_posix()):
        relative = source.relative_to(payload_root)
        destination = repository_root / relative
        if source.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied += 1
    return copied


def install(repository_root: Path, package_root: Path) -> dict[str, object]:
    repository_root = repository_root.resolve()
    project_path = repository_root / "project.json"
    if not project_path.is_file():
        raise RuntimeError("project.json is missing; this is not the WLX repository root")
    project = json.loads(project_path.read_text(encoding="utf-8"))
    if project.get("package_id") != PACKAGE_ID or project.get("set_code") != "WLX":
        raise RuntimeError("Refusing to install into a repository other than WLX")
    for required in (
        "automation/state.json",
        "cards/Alex/catalog.json",
        "cards/Will/catalog.json",
        "cards/Miguel/catalog.json",
        "cards/Jay/catalog.json",
    ):
        if not (repository_root / required).is_file():
            raise RuntimeError(f"Required canonical WLX source is missing: {required}")

    first_install = not (repository_root / MARKER).exists()
    removed: list[str] = []
    if first_install:
        # The abandoned importer owns the whole old imports directory, including
        # the 134 unprocessed images that the owner explicitly chose to discard.
        imports = repository_root / "imports"
        if imports.exists():
            remove_path(imports)
            removed.append("imports/")
        for relative in LEGACY_FILES:
            path = repository_root / relative
            if path.exists() or path.is_symlink():
                remove_path(path)
                removed.append(relative)
        for relative in LEGACY_DIRECTORIES:
            path = repository_root / relative
            if path.exists() or path.is_symlink():
                remove_path(path)
                removed.append(relative + "/")

    form_dir = repository_root / ".github" / "ISSUE_TEMPLATE"
    for filename in LEGACY_ISSUE_FORMS:
        path = form_dir / filename
        if path.exists():
            path.unlink()
            removed.append(f".github/ISSUE_TEMPLATE/{filename}")

    payload_root = package_root / "repository"
    if not payload_root.is_dir():
        raise RuntimeError("Installer payload is missing its repository directory")
    copied = copy_payload(payload_root, repository_root)
    (repository_root / MARKER).write_text(
        "WLX repository-backed bulk importer v3.0 installed.\n",
        encoding="utf-8",
        newline="\n",
    )
    return {
        "first_install": first_install,
        "removed": removed,
        "copied_files": copied,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository-root", type=Path, required=True)
    parser.add_argument(
        "--package-root", type=Path, default=Path(__file__).resolve().parent
    )
    arguments = parser.parse_args()
    try:
        result = install(arguments.repository_root, arguments.package_root)
    except Exception as exc:
        print(f"INSTALL ERROR: {exc}")
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
